export const theme = {
  colorGreen: "#29b365",
  colorWhite: "#fff",
  colors: {
    backgroundColor: "#FFFFE6",
    backgroundHighlightColor: "#E60B15",
    textColor: "#1b1b1b",
    textHighlightColor: "#f0f0f0",
  },
};
